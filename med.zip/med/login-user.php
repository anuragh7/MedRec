<?php require_once "controllerUserData.php"; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login Form</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div style="text-align:center!important;margin-top:25px;">
		<img src="img/MedRec.png"  width="300" height="120" alt="MedRec logo">
	</div>
    <div class="container" style="margin-top:60px;">
        <div class="row">
            <div class="col-md-4 offset-md-4 form login-form">
                <form action="login-user.php" method="POST" autocomplete="">
                    <h3 class="text-center">Login</h3><br>
                    <?php
                    if(count($errors) > 0){
                        ?>
                        <div class="alert alert-danger text-center">
                            <?php
                            foreach($errors as $showerror){
                                echo $showerror;
                            }
                            ?>
                        </div>
                        <?php
                    }
                    ?>
                    <div class="form-group">
                        <input class="form-control" type="email" name="email" placeholder="Email Address" required value="<?php echo $email ?>">
                    </div>
                    <div class="form-group">
                        <input class="form-control" type="password" name="password" placeholder="Password" required>
                    </div><br>
                    <div class="link forget-pass text-left"><a href="forgot-password.php">Forgot or Update Password?</a></div>
                    <div class="form-group">
                        <input class="form-control button" type="submit" name="login" value="Login">
                    </div>
                    </form>
            </div>
        </div>
        <div style="text-align:center!important;margin-top:50px;">
			Copyright &copy; 2022 &mdash; MedRec
		</div><br>
    </div>
    
</body>
</html>