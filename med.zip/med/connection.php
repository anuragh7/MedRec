<?php 
$con = mysqli_connect('localhost', 'id18502758_medteam_medrec', 'MedRec@9515943115', 'id18502758_medteam');
?>