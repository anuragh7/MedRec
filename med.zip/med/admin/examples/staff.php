<?php 
require_once('managepatient.php'); 
$con3= mysqli_connect('localhost', 'id18502758_medteam_medrec', 'MedRec@9515943115', 'id18502758_medteam');
$key = $_SESSION['email'];
$sel = mysqli_query($con3, 'SELECT * FROM medteam WHERE email = "'.$key.'" ');
$r = mysqli_fetch_array($sel)
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <title>
    Manage Patients | MedRec
  </title>
  <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
  <!--     Fonts and icons     -->
  <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css">
  <!-- CSS Files -->
  <link href="../assets/css/material-dashboard.css?v=2.1.0" rel="stylesheet" />
  <link rel="icon" type="image/x-icon" href="C:/Users/Anuragh/Desktop/Capstone/Website/assets/images/favicon.png">
</head>

<body class="dark-edition">
  <div class="wrapper ">
    <div class="sidebar" data-color="azure" data-background-color="black">
      <!--
        Tip 1: You can change the color of the sidebar using: data-color="purple | azure | green | orange | danger"

        Tip 2: you can also add an image using data-image tag
    -->
    <div class="logo" style="text-align:center!important;margin-top:25px;">
        <img src="img/MedRec.gif"  width="150" height="60" alt="MedRec logo">
      </div>

      <div class="sidebar-wrapper">
        <ul class="nav">
          <li class="nav-item ">
            <a class="nav-link" href="./dashboard.php">
              <i class="material-icons">dashboard</i>
              <p>Dashboard</p>
            </a>
        </li>
          <li class="nav-item ">
            <a class="nav-link" href="./user.php">
              <i class="material-icons">person</i>
              <p>Manage Patients</p>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="./lab.php">
              <i class="material-icons">library_books</i>
              <p>Laboratory</p>
            </a>
          </li>
          <li class="nav-item active">
            <a class="nav-link" href="./staff.php">
              <i class="material-icons">content_paste</i>
              <p>Manage Staff</p>
            </a>
          </li>
          <li class="nav-item ">
            <a class="nav-link" href="logout-user.php">
              <i class="material-icons">logout</i>
              <p>Logout</p>
            </a>
          </li>
        </ul>
      </div>
    </div>
    <div class="main-panel">
      <!-- Navbar -->
      <nav class="navbar navbar-expand-lg navbar-transparent navbar-absolute fixed-top " id="navigation-example">
        <div class="container-fluid">

          <button class="navbar-toggler" type="button" data-toggle="collapse" aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation" data-target="#navigation-example">
            <span class="sr-only">Toggle navigation</span>
            <span class="navbar-toggler-icon icon-bar"></span>
            <span class="navbar-toggler-icon icon-bar"></span>
            <span class="navbar-toggler-icon icon-bar"></span>
          </button>
          <div class="collapse navbar-collapse justify-content-end">
            <form class="navbar-form">
              <div class="input-group no-border">
                <input type="text" value="" class="form-control" placeholder="Search...">
                <button type="submit" class="btn btn-default btn-round btn-just-icon">
                  <i class="material-icons">search</i>
                  <div class="ripple-container"></div>
                </button>
              </div>
            </form>
            <ul class="navbar-nav">

              <li class="nav-item dropdown">
                <a class="nav-link" href="javscript:void(0)" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  <i class="material-icons">notifications</i>
                  <span class="notification">3</span>
                  <p class="d-lg-none d-md-block">
                    Some Actions
                  </p>
                </a>
                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownMenuLink">
                  <a class="dropdown-item" href="./user.php">Admit or Discharge patient in 'Manage Patients' tab</a>
                  <a class="dropdown-item" href="./lab.php">Upload Patients in 'Laboratory' tab</a>
                  <a class="dropdown-item" href="./staff.php">Setup Login Credentials for your doctors in 'Manage Staff'</a>
                </div>
            </ul>
          </div>
        </div>
      </nav>
      <!-- End Navbar -->
      <div class="content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-12">
              <div class="card">
                <div class="card-header card-header-primary">
                  <h4 class="card-title">Add Doctor Profile</h4>
                </div>
                <div class="card-body">
                  <br><form action="staff.php" method="POST">
                    
                    <div class="row">
                    <div class="col-md-2">
                        <div class="form-group">
                          <label class="bmd-label-floating">Doctor Name</label>
                          <input type="text" name = "dname" class="form-control" required>
                        </div></div>
   
                    <div class="col-md-2">
                        <div class="form-group">
                          <label class="bmd-label-floating">E-mail ID</label>
                          <input type="text" name = "dmail" class="form-control" required>
                        </div>
                      </div>

                    <div class="col-md-2">
                        <div class="form-group">
                          <label class="bmd-label-floating">Mobile</label>
                          <input type="text" name = "dmobile" class="form-control" pattern="[789][0-9]{9}" required>
                        </div>
                      </div>
                      <div class="col-md-2">
                        <div class="form-group">
                          <label class="bmd-label-floating">Create a password</label>
                          <input type="password" name = "dpass" class="form-control" required>
                        </div></div>

                        <div class="col-md-2">
                        <div class="form-group">
                          <label class="bmd-label-floating">Confirm password</label>
                          <input type="password" name = "cnfpass" class="form-control" required>
                        </div></div>

                    </div>
                      <br>

                    <div class="row">
                      <div class="col-md-2">
                        <div class="form-group">
                          <label class="bmd-label-floating">Associated Hospital</label>
                          <input type="text" name = "dhosp"  value="<?php echo $r['name']; ?>" class="form-control" disabled>
                        </div>
                      </div>

                      <div class="col-md-2">
                        <div class="form-group">
                          <label class="bmd-label-floating">Doctor ID</label>
                          <input type="text" name = "did" value="" class="form-control" required> 
                        </div>
                      </div>

                      <div class="col-md-3">
                        <div class="form-group">
                        <label id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="bmd-label-floating dropdown">Choose Specialization</label>
                          <select required name = "dspl"  class="dropdown" style=" background-color: transparent;border: 0;color: grey;
                          padding-top:7px; box-shadow: none, 0 0 0 0.2rem rgba(33, 150, 243, 0.25);
                          ">
                          <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownMenuLink">
                            <option value="" hidden>Click here to Select</option>
                            <option class="dropdown-item" style="color: black" value="Gynaecology"> Gynaecology </option>
                            <option style="color: black" value="General Surgery"> General Surgery</option>
                            <option style="color: black" value="Pediatrics"> Pediatrics </option>
                            <option style="color: black" value="Radiology"> Radiology </option>
                            <option style="color: black" value="Dermatology"> Dermatology </option>
                            <option style="color: black"  value="ENT"> ENT </option>
                            <option style="color: black" value="Oncology"> Oncology </option>
                            <option style="color: black" value="Cardiology"> Cardiology </option>
                            <option style="color: black" value="Dermatology"> Dermatology </option>
                            <option style="color: black" value="Internal Medicine"> Internal Medicine </option>
                            <option style="color: black" value="Pulmonology"> Pulmonology </option>
                            <option style="color: black" value="Gastroenterology"> Gastroenterology </option>
                            <option style="color: black" value="Dermatology"> Dermatology </option>
                            <option style="color: black" value="Nephrology"> Nephrology </option>
                            <option style="color: black" value="Neurology"> Neurology </option>
                            <option style="color: black" value="Psychology"> Psychology </option>
                            <option style="color: black" value="Dermatology"> Dermatology </option>
                            <option style="color: black" value="Anesthesia"> Anesthesia </option>
                            <option style="color: black" value="Endocrinology"> Endocrinology </option>
                            <option style="color: black" value="Physiotherapy"> Physiotherapy </option>
</div>
                        </select>
                        </div>
                    </div></div><br>
                    <div class="row">
                    <div class="col-md-1">
                    <div class="form-group">
                      <button type="submit" name="staff" class="btn btn-primary pull-left">Setup Profile</button>
                    </div>
                    </div>
                      </div>
                      <br>
                </div>
                  </form>
                </div>
              </div>

      <script>
        const x = new Date().getFullYear();
        let date = document.getElementById('date');
        date.innerHTML = '&copy; ' + x + date.innerHTML;
      </script>
    </div>
  </div>
  <!--   Core JS Files   -->
  <script src="../assets/js/core/jquery.min.js"></script>
  <script src="../assets/js/core/popper.min.js"></script>
  <script src="../assets/js/core/bootstrap-material-design.min.js"></script>
  <script src="https://unpkg.com/default-passive-events"></script>
  <script src="../assets/js/plugins/perfect-scrollbar.jquery.min.js"></script>
  <!-- Place this tag in your head or just before your close body tag. -->
  <script async defer src="https://buttons.github.io/buttons.js"></script>
  <!--  Google Maps Plugin    -->
  <script src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script>
  <!-- Chartist JS -->
  <script src="../assets/js/plugins/chartist.min.js"></script>
  <!--  Notifications Plugin    -->
  <script src="../assets/js/plugins/bootstrap-notify.js"></script>
  <!-- Control Center for Material Dashboard: parallax effects, scripts for the example pages etc -->
  <script src="../assets/js/material-dashboard.js?v=2.1.0"></script>
  <!-- Material Dashboard DEMO methods, don't include it in your project! -->
  <script src="../assets/demo/demo.js"></script>
  <script>
    $(document).ready(function() {
      $().ready(function() {
        $sidebar = $('.sidebar');

        $sidebar_img_container = $sidebar.find('.sidebar-background');

        $full_page = $('.full-page');

        $sidebar_responsive = $('body > .navbar-collapse');

        window_width = $(window).width();

        $('.fixed-plugin a').click(function(event) {
          // Alex if we click on switch, stop propagation of the event, so the dropdown will not be hide, otherwise we set the  section active
          if ($(this).hasClass('switch-trigger')) {
            if (event.stopPropagation) {
              event.stopPropagation();
            } else if (window.event) {
              window.event.cancelBubble = true;
            }
          }
        });

        $('.fixed-plugin .active-color span').click(function() {
          $full_page_background = $('.full-page-background');

          $(this).siblings().removeClass('active');
          $(this).addClass('active');

          var new_color = $(this).data('color');

          if ($sidebar.length != 0) {
            $sidebar.attr('data-color', new_color);
          }

          if ($full_page.length != 0) {
            $full_page.attr('filter-color', new_color);
          }

          if ($sidebar_responsive.length != 0) {
            $sidebar_responsive.attr('data-color', new_color);
          }
        });

        $('.fixed-plugin .background-color .badge').click(function() {
          $(this).siblings().removeClass('active');
          $(this).addClass('active');

          var new_color = $(this).data('background-color');

          if ($sidebar.length != 0) {
            $sidebar.attr('data-background-color', new_color);
          }
        });

        $('.fixed-plugin .img-holder').click(function() {
          $full_page_background = $('.full-page-background');

          $(this).parent('li').siblings().removeClass('active');
          $(this).parent('li').addClass('active');


          var new_image = $(this).find("img").attr('src');

          if ($sidebar_img_container.length != 0 && $('.switch-sidebar-image input:checked').length != 0) {
            $sidebar_img_container.fadeOut('fast', function() {
              $sidebar_img_container.css('background-image', 'url("' + new_image + '")');
              $sidebar_img_container.fadeIn('fast');
            });
          }

          if ($full_page_background.length != 0 && $('.switch-sidebar-image input:checked').length != 0) {
            var new_image_full_page = $('.fixed-plugin li.active .img-holder').find('img').data('src');

            $full_page_background.fadeOut('fast', function() {
              $full_page_background.css('background-image', 'url("' + new_image_full_page + '")');
              $full_page_background.fadeIn('fast');
            });
          }

          if ($('.switch-sidebar-image input:checked').length == 0) {
            var new_image = $('.fixed-plugin li.active .img-holder').find("img").attr('src');
            var new_image_full_page = $('.fixed-plugin li.active .img-holder').find('img').data('src');

            $sidebar_img_container.css('background-image', 'url("' + new_image + '")');
            $full_page_background.css('background-image', 'url("' + new_image_full_page + '")');
          }

          if ($sidebar_responsive.length != 0) {
            $sidebar_responsive.css('background-image', 'url("' + new_image + '")');
          }
        });

        $('.switch-sidebar-image input').change(function() {
          $full_page_background = $('.full-page-background');

          $input = $(this);

          if ($input.is(':checked')) {
            if ($sidebar_img_container.length != 0) {
              $sidebar_img_container.fadeIn('fast');
              $sidebar.attr('data-image', '#');
            }

            if ($full_page_background.length != 0) {
              $full_page_background.fadeIn('fast');
              $full_page.attr('data-image', '#');
            }

            background_image = true;
          } else {
            if ($sidebar_img_container.length != 0) {
              $sidebar.removeAttr('data-image');
              $sidebar_img_container.fadeOut('fast');
            }

            if ($full_page_background.length != 0) {
              $full_page.removeAttr('data-image', '#');
              $full_page_background.fadeOut('fast');
            }

            background_image = false;
          }
        });

        $('.switch-sidebar-mini input').change(function() {
          $body = $('body');

          $input = $(this);

          if (md.misc.sidebar_mini_active == true) {
            $('body').removeClass('sidebar-mini');
            md.misc.sidebar_mini_active = false;

            $('.sidebar .sidebar-wrapper, .main-panel').perfectScrollbar();

          } else {

            $('.sidebar .sidebar-wrapper, .main-panel').perfectScrollbar('destroy');

            setTimeout(function() {
              $('body').addClass('sidebar-mini');

              md.misc.sidebar_mini_active = true;
            }, 300);
          }

          // we simulate the window Resize so the charts will get updated in realtime.
          var simulateWindowResize = setInterval(function() {
            window.dispatchEvent(new Event('resize'));
          }, 180);

          // we stop the simulation of Window Resize after the animations are completed
          setTimeout(function() {
            clearInterval(simulateWindowResize);
          }, 1000);

        });
      });
    });
  </script>
</body>

</html>