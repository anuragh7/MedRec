<?php 
$con = mysqli_connect('localhost', 'id18502758_patient_medrec', 'MedRec@9515943115', 'id18502758_patient');
$con2= mysqli_connect('localhost', 'id18502758_medteam_medrec', 'MedRec@9515943115', 'id18502758_medteam');
session_start();
?>

<!DOCTYPE HTML>
<head></head>
<body>

<?php
if(isset($_POST['details']))
{
    $patientid = mysqli_real_escape_string($con, $_POST['patientid']);
    $check_pid = "SELECT * FROM usertable WHERE patientid = '$patientid' ";
    $res = mysqli_query($con, $check_pid);

    if(mysqli_num_rows($res) > 0)
        {
            $_SESSION['patientid'] = $patientid;
            $_SESSION['pname'] = $r['name'];
            $pid = $_SESSION['patientid'];
            header('location: upload.php');
        }
    else{echo '<script>alert("No Patient available with this code..")</script>';}
}

if(isset($_POST['upload']))
{   
    $con3= mysqli_connect('localhost', 'id18502758_medteam_medrec', 'MedRec@9515943115', 'id18502758_medteam');
    $key = $_SESSION['email'];
    $sel2 = mysqli_query($con3, 'SELECT * FROM medteam WHERE email = "'.$key.'" ');
    $h = mysqli_fetch_array($sel2);
    $hosp = $h['name'];
    $file = $_FILES["uploadfile"]["name"];
    $temp = $_FILES["uploadfile"]["tmp_name"];    
    $folder = "reports/".$file;
    move_uploaded_file($temp, $folder);
    $pid = $_SESSION['patientid'];
    $sel = mysqli_query($con, "SELECT * FROM usertable WHERE patientid = '$pid' ");
    $r = mysqli_fetch_array($sel);
    $pname = $r['name'];
    $type = mysqli_real_escape_string($con, $_POST['type']);
    $date = date("Y-m-d");
    $upload = "INSERT into reports (pname, type, file, dt, upby) values ('$pname', '$type', '$file', '$date', '$hosp')";
    $uploadreport = mysqli_query($con, $upload);
    echo '<script>alert("File uploaded.")</script>';
}

?>
</body>
</html>