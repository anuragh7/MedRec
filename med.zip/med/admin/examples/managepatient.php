<?php 
$con = mysqli_connect('localhost', 'id18502758_patient_medrec', 'MedRec@9515943115', 'id18502758_patient');
$con2= mysqli_connect('localhost', 'id18502758_medteam_medrec', 'MedRec@9515943115', 'id18502758_medteam');
$con3= mysqli_connect('localhost', 'id18502758_medteam_medrec', 'MedRec@9515943115', 'id18502758_medteam');
session_start();
$allot="";
?>

<!DOCTYPE HTML>
<head></head>
<body>

<?php
if(isset($_POST['details']))
{
    $patientid = mysqli_real_escape_string($con, $_POST['patientid']);
    $check_pid = "SELECT * FROM usertable WHERE patientid = '$patientid' ";
    $res = mysqli_query($con, $check_pid);
    $r = mysqli_fetch_array($res);
    if(mysqli_num_rows($res) > 0)
        {
            $_SESSION['patientid'] = $patientid;
            $_SESSION['pname'] = $r['name'];
            $pid = $_SESSION['patientid'];
            $sel = mysqli_query($con, "SELECT * FROM usertable WHERE patientid = '$pid' ");
            $r = mysqli_fetch_array($sel);
            $pname = $r['name'];
            $pquery="SELECT pname FROM allot WHERE pname = '$pname' ";
            $pverify = mysqli_query($con2, $pquery);

            $key = $_SESSION['email'];
            $con3= mysqli_connect('localhost', 'id18502758_medteam_medrec', 'MedRec@9515943115', 'id18502758_medteam');
            $sel = mysqli_query($con3, 'SELECT * FROM medteam WHERE email = "'.$key.'" ');
            $r = mysqli_fetch_array($sel);

            if(mysqli_num_rows($pverify) > 0)
            {
            $check_allot = "SELECT * FROM allot WHERE pname = '$pname' ";
            $alloted = mysqli_query($con2, $check_allot);
            $s = mysqli_fetch_array($alloted);
                if($s['hospital']==$r['name'])
                {       
                    if($s['status']=="discharged")
                    {
                        header('location: details.php');
                    }
                    else {echo '<script>alert("Patient already Admitted.")</script>';}
                }
                else{echo '<script>alert("Patient already Admitted at other Hospital.")</script>';}
            }

            else{ header('location: details.php');  }
            }
            else
            {
                echo '<script>alert("No Patient available with this code.")</script>';
            }

}

if(isset($_POST['find']))
{   $_SESSION['pname'] = $pname;
    $spl = mysqli_real_escape_string($con2, $_POST['spl']);
    $_SESSION['spl'] = $spl;
    header('location: allot.php');   
}

if(isset($_POST['allot']))
{
    $spl = $_SESSION['spl'];
    $pid = $_SESSION['patientid'];
    $sel = mysqli_query($con, "SELECT * FROM usertable WHERE patientid = '$pid' ");
    $r = mysqli_fetch_array($sel);
    $pname = $r['name'];
    $dname = mysqli_real_escape_string($con2, $_POST['dname']);

    $pquery="SELECT pname FROM allot WHERE pname = '$pname' ";
    $pverify = mysqli_query($con2, $pquery);
    $p = mysqli_fetch_array($pverify);
    if($dname!="")
    {
        if(mysqli_num_rows($pverify)==0)
        {
        $key = $_SESSION['email'];
        $sel = mysqli_query($con3, 'SELECT * FROM medteam WHERE email = "'.$key.'" ');
        $r = mysqli_fetch_array($sel);
        $hosp=$r['name'];
        $dt = date("Y-m-d");
        $update_allot="INSERT into allot (pname, doctor, specialization, status, dat, hospital) values ('$pname', '$dname', '$spl', 'admitted', '$dt', '$hosp')";
        $update=mysqli_query($con2,$update_allot);
        echo '<script>alert("Patient Admitted Succesfully.")</script>';
        }
        else{
            $squery="SELECT * FROM allot WHERE pname = '$pname' AND status = 'discharged' ";
            $sverify = mysqli_query($con2, $squery);
            $s = mysqli_fetch_array($sverify);
            $key = $_SESSION['email'];
            $sel = mysqli_query($con3, 'SELECT * FROM medteam WHERE email = "'.$key.'" ');
            $r = mysqli_fetch_array($sel);
            $hosp=$r['name'];
            if(mysqli_num_rows($sverify) > 0)
            {
                $dt = date("Y-m-d");
                $update_allot="UPDATE allot SET specialization = '$spl', status = 'admitted', doctor = '$dname', dat = '$dt', hospital = '$hosp'
                WHERE pname = '$pname'";
                $update=mysqli_query($con2,$update_allot);
                echo '<script>alert("Patient Admitted Succesfully.")</script>';
            }
            else{echo '<script>alert("Patient has already been Admitted.")</script>';}

        }
    }
    else{
        echo '<script>alert("Select Available Staff.")</script>';
    }
}

if(isset($_POST['disdet']))
{
    $patientid = mysqli_real_escape_string($con, $_POST['patientid']);
    $check_pid = "SELECT * FROM usertable WHERE patientid = '$patientid' ";
    $res = mysqli_query($con, $check_pid);
    $r = mysqli_fetch_array($res);
    if(mysqli_num_rows($res) > 0)
        {
            $_SESSION['patientid'] = $patientid;
            $_SESSION['pname'] = $r['name'];
            $pname = $r['name'];
            $key = $_SESSION['email'];
            $sel = mysqli_query($con3, 'SELECT * FROM medteam WHERE email = "'.$key.'" ');
            $x = mysqli_fetch_array($sel);
            $hosp = $x['name'];
            $pquery= "SELECT pname FROM allot WHERE pname = '$pname'";
            $pverify = mysqli_query($con2, $pquery);
            $check_allot = "SELECT * FROM allot WHERE pname = '$pname' ";
            $alloted = mysqli_query($con2, $check_allot);
            $s = mysqli_fetch_array($alloted);

            $key = $_SESSION['email'];
            $con3= mysqli_connect('localhost', 'id18502758_medteam_medrec', 'MedRec@9515943115', 'id18502758_medteam');
            $sel = mysqli_query($con3, 'SELECT * FROM medteam WHERE email = "'.$key.'" ');
            $r = mysqli_fetch_array($sel);

            if (mysqli_num_rows($pverify) > 0 )
            {
                if($s['hospital']==$r['name'])
            {
                if($s['status']=="admitted")
                {
                header('location: discharge.php');
                }
                else{echo '<script>alert("Patient is already Discharged.")</script>';}
            }
               else
            { 
                echo '<script>alert("Patient is not Admitted at our Hospital.")</script>';
            }
            
            }

            else {echo '<script>alert("Patient is not Admitted.")</script>';}
            
}
            
            else
                {
                    echo '<script>alert("No Patient available with this code.")</script>';
                }
}


if(isset($_POST['discharge']))
{

        $patientid=  $_SESSION['patientid'] ;
        $treatment = mysqli_real_escape_string($con2, $_POST['treatment']);
        $med = mysqli_real_escape_string($con2, $_POST['med']);
        $check_pid = "SELECT * FROM usertable WHERE patientid = '$patientid' ";
        $res = mysqli_query($con, $check_pid);
        $r = mysqli_fetch_array($res);
        $_SESSION['pname'] = $r['name'];
        $pname = $r['name'];

        $check_stat = "SELECT * FROM allot WHERE pname = '$pname' ";
        $stat = mysqli_query($con2, $check_stat);
        $s = mysqli_fetch_array($stat);

        if($s['status'] == "admitted")
        {
        $dt = date("Y-m-d");
        $update_status="UPDATE allot SET status ='discharged', dat = '$dt' WHERE pname = '".$pname."' ";
        $discharge = mysqli_query($con2, $update_status);
        $update_treatment = "UPDATE usertable SET operations = concat(operations, '\n\n', '$dt', ':', '\n', '$treatment'), medications = '$med'  WHERE name = '".$pname."'";
        $update_patient = mysqli_query($con, $update_treatment);
        echo '<script>alert("Patient Discharged.")</script>';
        }

        else{
            echo '<script>alert("Patient Already Discharged.")</script>';
        }
    }

if(isset($_POST['staff']))
{
    $dname = mysqli_real_escape_string($con2, $_POST['dname']);
    $dmail = mysqli_real_escape_string($con2, $_POST['dmail']);
    $dmobile = mysqli_real_escape_string($con2, $_POST['dmobile']);
    $dpass = mysqli_real_escape_string($con2, $_POST['dpass']);
    $cnfpass = mysqli_real_escape_string($con2, $_POST['cnfpass']);
    $key = $_SESSION['email'];
    $sel = mysqli_query($con3, 'SELECT * FROM usertable WHERE email = "'.$key.'" ');
    $r = mysqli_fetch_array($sel);
    $dhosp = $r['name'];
    $did = mysqli_real_escape_string($con2, $_POST['did']);
    $dspl = mysqli_real_escape_string($con2, $_POST['dspl']);
    $checkd="SELECT * from usertable WHERE name = '$dname' OR doctorid = '$did' OR email = '$dmail' OR mobile = '$dmobile' ";
    $check_d=mysqli_query($con2,$checkd);

    if(mysqli_num_rows($check_d)==0)
    {
    if($dpass==$cnfpass)
    {
        $add_q="INSERT INTO usertable (name, mobile, email, password, doctorid, specialization, hospital) values ('$dname', '$dmobile', '$dmail', '$dpass', '$did', '$dspl', '$dhosp') ";
        $add_doc=mysqli_query($con2,$add_q);
        echo '<script>alert("Doctor Profile setup Succesful.")</script>';
    }
    else{ echo '<script>alert("Passwords do not match.")</script>'; }
}

else
{
    echo '<script>alert("Doctor Profile already registered")</script>';

}
}



?>
</body>
</html>